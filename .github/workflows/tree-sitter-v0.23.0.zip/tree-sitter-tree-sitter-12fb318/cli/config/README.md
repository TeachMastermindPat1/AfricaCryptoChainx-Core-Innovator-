# Tree-sitter Config

Manages Tree-sitter's configuration file.

You can use a configuration file to control the behavior of the `tree-sitter`
command-line program. This crate implements the logic for finding and the
parsing the contents of the configuration file.
