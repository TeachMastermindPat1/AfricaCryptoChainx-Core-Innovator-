module.exports = grammar({
  name: 'start_rule_is_token',

  rules: {
    first_rule: _ => 'the-value',
  },
});
